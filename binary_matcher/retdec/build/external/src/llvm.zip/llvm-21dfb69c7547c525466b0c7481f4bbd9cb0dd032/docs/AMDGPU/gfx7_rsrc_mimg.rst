..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid7_rsrc_mimg:

srsrc
===========================

Image resource constant which defines the location of the image buffer in memory, its dimensions, tiling, and data format.

*Size:* 8 dwords by default, 4 dwords if :ref:`r128<amdgpu_synid_r128>` is specified.

*Operands:* :ref:`s<amdgpu_synid_s>`, :ref:`ttmp<amdgpu_synid_ttmp>`
