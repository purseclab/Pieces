..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid9_ret:

dst
===========================

This is an input operand. It may optionally serve as a destination if :ref:`glc<amdgpu_synid_glc>` is specified.

