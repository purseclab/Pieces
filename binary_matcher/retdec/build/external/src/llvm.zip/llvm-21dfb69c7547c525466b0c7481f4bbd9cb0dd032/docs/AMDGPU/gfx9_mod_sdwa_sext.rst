..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid9_mod_sdwa_sext:

m
===========================

This operand may be used with integer operand modifier :ref:`sext<amdgpu_synid_sext>`.

