..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid8_data_buf_d16_32:

vdata
===========================

16-bit data to store by a buffer instruction.

*Size:* 1 dword.

*Operands:* :ref:`v<amdgpu_synid_v>`
