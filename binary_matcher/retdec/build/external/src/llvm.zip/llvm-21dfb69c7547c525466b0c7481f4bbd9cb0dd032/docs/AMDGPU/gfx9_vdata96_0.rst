..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid9_vdata96_0:

vdata
===========================

Instruction input.

*Size:* 3 dwords.

*Operands:* :ref:`v<amdgpu_synid_v>`
