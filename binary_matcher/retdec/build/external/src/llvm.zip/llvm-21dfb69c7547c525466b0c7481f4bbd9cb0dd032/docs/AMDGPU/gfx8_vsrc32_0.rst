..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid8_vsrc32_0:

vsrc
===========================

Instruction input.

*Size:* 1 dword.

*Operands:* :ref:`v<amdgpu_synid_v>`
