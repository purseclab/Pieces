..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid8_bimm16:

imm16
===========================

An :ref:`integer_number<amdgpu_synid_integer_number>`. The value is truncated to 16 bits.

