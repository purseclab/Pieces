..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid9_rsrc_mimg:

srsrc
===========================

Image resource constant which defines the location of the image buffer in memory, its dimensions, tiling, and data format.

*Size:* 8 dwords.

*Operands:* :ref:`s<amdgpu_synid_s>`, :ref:`ttmp<amdgpu_synid_ttmp>`
