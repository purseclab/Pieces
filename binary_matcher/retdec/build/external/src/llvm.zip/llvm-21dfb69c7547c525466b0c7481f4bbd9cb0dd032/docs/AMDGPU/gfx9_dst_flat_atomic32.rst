..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid9_dst_flat_atomic32:

vdst
===========================

Data returned by a 32-bit atomic flat instruction.

This is an optional operand. It must be used if and only if :ref:`glc<amdgpu_synid_glc>` is specified.

*Size:* 1 dword.

*Operands:* :ref:`v<amdgpu_synid_v>`
