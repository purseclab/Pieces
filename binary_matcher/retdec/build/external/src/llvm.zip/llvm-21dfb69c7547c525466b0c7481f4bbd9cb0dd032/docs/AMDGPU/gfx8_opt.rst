..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid8_opt:

opt
===========================

This is an optional operand. It must be used if and only if :ref:`glc<amdgpu_synid_glc>` is specified.

