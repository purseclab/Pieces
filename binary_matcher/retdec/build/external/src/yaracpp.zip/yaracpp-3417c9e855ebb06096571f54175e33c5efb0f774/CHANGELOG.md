# Changelog

# dev

* Updated YARA to version 3.8.1.
* Fixed build of libyara under 32b Unix-like systems ([avast/yara#1](https://github.com/avast/yara/pull/1)).
* Fixed cross-compilation ([#2](https://github.com/avast/yaracpp/pull/2)).

# v1.0.1 (2017-01-18)

* Fixed build of libyara with Visual Studio 2017 without the 2015 toolset.

# v1.0 (2017-12-12)

Initial release.
