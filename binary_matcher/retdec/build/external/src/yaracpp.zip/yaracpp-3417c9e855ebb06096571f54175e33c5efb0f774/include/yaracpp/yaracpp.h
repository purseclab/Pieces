/**
 * @file include/yaracpp/yaracpp.h
 * @brief Interface to yaracpp library.
 * @copyright (c) 2017 Avast Software, licensed under the MIT license
 */

#pragma once

#include "yaracpp/yara_detector/yara_detector.h"
